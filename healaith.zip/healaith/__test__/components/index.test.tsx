import SiteHeader from "@/components/SiteHeader"
import { render, screen } from "@testing-library/react"

describe("SiteHeader", () => {
  it("renders a heading", () => {
    render(<SiteHeader />)

    const logo = screen.getByAltText("logo")

    expect(logo).toBeInTheDocument()
  })
})
