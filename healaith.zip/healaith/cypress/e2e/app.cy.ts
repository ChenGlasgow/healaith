// Cypress E2E Test
describe("Navigation", () => {
  it("should navigate to the about page", () => {
    cy.visit("http://localhost:3000/")

    cy.get('[role="demolink"]').click()

    cy.url().should("include", "/demo")
  })
})

export {}
