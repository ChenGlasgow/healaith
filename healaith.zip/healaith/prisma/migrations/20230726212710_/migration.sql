/*
  Warnings:

  - You are about to drop the column `message` on the `ChatRecord` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ChatRecord" DROP COLUMN "message",
ADD COLUMN     "messages" JSONB[];
