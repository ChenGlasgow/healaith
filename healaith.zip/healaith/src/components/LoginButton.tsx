"use client"

import { Button, Form, Input, Modal } from "antd"
import Link from "next/link"
import { useState } from "react"

interface Values {
  title: string
  description: string
  modifier: string
}

interface CollectionCreateFormProps {
  open: boolean
  onCreate: (values: Values) => void
  onCancel: () => void
}

const LoginButton = ({ buttonText }: { buttonText: string }) => {
  const CollectionCreateForm: React.FC<CollectionCreateFormProps> = ({
    open,
    onCreate,
    onCancel,
  }) => {
    const [form] = Form.useForm()
    return (
      <Modal
        open={open}
        title={
          <div className="flex items-center justify-center text-center">
            <h2>Log in</h2>
          </div>
        }
        okText="Login"
        cancelText="Cancel"
        onCancel={onCancel}
        onOk={() => {
          form
            .validateFields()
            .then((values) => {
              form.resetFields()
              onCreate(values)
            })
            .catch((info) => {
              console.log("Validate Failed:", info)
            })
        }}
      >
        <Form
          form={form}
          layout="vertical"
          name="form_in_modal"
          initialValues={{ modifier: "public" }}
        >
          <Form.Item
            name="Username"
            label="Username"
            // rules={[{ required: true, message: 'Please input the Username!' }]}
          >
            <Input />
          </Form.Item>
          <Form.Item name="Password" label="Password">
            <Input type="textarea" />
          </Form.Item>
          <Form.Item
            name="modifier"
            className="collection-create-form_last-form-item"
          >
            <div>
              Don't have an account? <Link href="/register">register</Link>
            </div>
          </Form.Item>
        </Form>
      </Modal>
    )
  }

  const [open, setOpen] = useState(false)

  const onCreate = (values: any) => {
    console.log("Received values of form: ", values)
    setOpen(false)
  }

  return (
    <>
      <Button
        type="primary"
        size="large"
        onClick={() => {
          setOpen(true)
        }}
      >
        {buttonText}
      </Button>
      <CollectionCreateForm
        open={open}
        onCreate={onCreate}
        onCancel={() => {
          setOpen(false)
        }}
      />
    </>
  )
}

export default LoginButton
