import { Button, Layout, Menu, MenuProps } from "antd"
import { signIn, useSession } from "next-auth/react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/router"

const { Header } = Layout

const SiteHeader = () => {
  const { data: session, status } = useSession()
  const router = useRouter()

  const renderLoginButton = () => {
    if (session) {
      return <span>Hi, {session.user?.email}</span>
    }
    return <Button onClick={() => signIn()}>Login</Button>
  }

  const items: MenuProps["items"] = [
    {
      label: <Link href="/">Home</Link>,
      key: "/home",
    },
    {
      label: <Link href="/chat">Chat</Link>,
      key: "/chat",
    },
    {
      label: <Link href="/demo">Demo</Link>,
      key: "/demo",
    },
    {
      label: <Link href="/MedicalHistorySetting">MedicalHistorySetting</Link>,
      key: "/MedicalHistorySetting",
    },
  ]

  return (
    <div className="bg-white flex items-center justify-between px-10 py-2">
      <div className="flex items-center">
        <Image
          alt="logo"
          width={70}
          height={50}
          style={{ borderRadius: "50%" }}
          src="/logo.png"
          className="mr-2"
        />
        <Menu
          selectedKeys={[router.pathname]}
          mode="horizontal"
          items={items}
          style={{
            borderBottom: "none",
          }}
        />
      </div>
      {renderLoginButton()}
    </div>
  )
}
export default SiteHeader
