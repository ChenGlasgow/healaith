// components/Dialogue.js
import React from "react"

const Dialogue = ({
  messages,
}: {
  messages: {
    content: string
    isLeft: boolean
  }[]
}) => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
      }}
    >
      {messages.map((message, index) => (
        <div
          key={index}
          style={{
            margin: "5px",
            padding: "10px",
            borderRadius: "5px",
            maxWidth: "70%",
            alignSelf: message.isLeft ? "flex-start" : "flex-end",
            backgroundColor: message.isLeft ? "#f1f0f0" : "#d3e6ff",
          }}
        >
          {message.content}
        </div>
      ))}
    </div>
  )
}

export default Dialogue
