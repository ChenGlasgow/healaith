import { ConfigProvider } from "antd"
import { SessionProvider } from "next-auth/react"

const Providers = ({
  children,
  session,
}: {
  children: React.ReactNode
  session: any
}) => {
  return (
    <SessionProvider session={session}>
      <ConfigProvider
        theme={{
          token: {
            colorPrimary: "#0891b2",
            // colorText: "#eee",
            // colorBgContainer: "#000",
          },
        }}
      >
        {children}
      </ConfigProvider>
    </SessionProvider>
  )
}

export default Providers
