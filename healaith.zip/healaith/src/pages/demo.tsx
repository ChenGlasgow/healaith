"use client"

import { Button, Form, Layout, Rate, theme } from "antd"
import { useSession } from "next-auth/react"
import Link from "next/link"
import React, { useEffect, useState } from "react"

import Dialogue from "@/components/Dialogue"
import SiteHeader from "@/components/SiteHeader"
import { QuestionCircleOutlined } from "@ant-design/icons"

const { Content, Footer } = Layout

const dialogues = [
  { content: "Welcome to the HealAIth. How can I assist you?", isLeft: true },
  {
    content:
      "I have been feeling headaches and fatigue recently, sometimes accompanied by nausea. I don't know what could be causing it. Can you give me some advice?",
    isLeft: false,
  },
  {
    content:
      "I can help you analyze the possible reasons. Headache and fatigue are common symptoms that can be caused by various factors. First, do you have any accompanying symptoms such as fever, cough, or sore throat? This helps to rule out headaches and fatigue caused by infections.",
    isLeft: true,
  },
  {
    content: "Hmm, I don't have a fever, cough, or sore throat.",
    isLeft: false,
  },
  {
    content:
      "Okay, this helps narrow it down. Besides infection, headaches and fatigue may also be related to other factors. For example, have you recently experienced lack of sleep or excessive stress? These factors could also be causing these symptoms for you.",
    isLeft: true,
  },
  {
    content: "Recently work is really busy, may indeed lack of sleep.",
    isLeft: false,
  },
  {
    content:
      "Understood. Lack of sleep and excessive fatigue can lead to tiredness and headaches. I suggest you try adjusting your schedule to ensure you get enough sleep every night and give yourself enough rest time. In addition, you can also try some relaxation activities such as deep breathing, meditation, or light exercise to relieve stress and improve symptoms.",
    isLeft: true,
  },
  { content: "Okay, I'll try that. Thanks for the advice!", isLeft: false },
  {
    content:
      "You're welcome! I hope my advice will be helpful to you. If your symptoms persist or worsen, I suggest you consult a local medical professional for further evaluation and treatment. I wish you a speedy recovery!",
    isLeft: true,
  },
]

const App: React.FC = () => {
  const {
    token: { colorBgContainer },
  } = theme.useToken()
  const [form] = Form.useForm()
  const { data: session, status } = useSession()
  const [rating, setRating] = useState(2.5)

  const onFinish = async (value: number) => {
    try {
      await fetch("/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          rating: value,
        }),
      })
      console.log("Feedback sent successfully!")
    } catch (error) {
      console.error("Error sending feedback:", error)
    }
  }

  useEffect(() => {
    if (session) {
      fetch("/api/feedback")
        .then((res) => res.json())
        .then((data) => {
          const averageRating =
            data.reduce(
              (sum: any, feedback: { rating: any }) => sum + feedback.rating,
              0,
            ) / data.length
          setRating(averageRating)
        })
        .catch((error) => {
          console.error("Error fetching feedback data:", error)
        })
    }
  }, [session])

  return (
    <Layout className="layout min-h-screen">
      <SiteHeader />
      <Content style={{ padding: "0 50px" }} className="flex justify-center">
        <div
          className="site-layout-content flex justify-center flex-col items-center text-center w-full"
          style={{ background: colorBgContainer }}
        >
          <div className=" h-96 w-full bg-slate-200 overflow-auto ">
            <Dialogue messages={dialogues} />
          </div>
          <Rate
            allowHalf
            value={rating}
            className="m-3"
            onChange={(value) => {
              setRating(value)
              onFinish(value)
            }}
          />
        </div>
        <Link href="/demo">
          <div>
            <Button
              type="primary"
              shape="circle"
              icon={<QuestionCircleOutlined />}
              style={{
                position: "fixed",
                right: 24,
                bottom: 24,
                marginBottom: "24px",
              }}
            />
          </div>
        </Link>
      </Content>

      <Footer style={{ textAlign: "center" }}>©HealAIth</Footer>
    </Layout>
  )
}

export default App
