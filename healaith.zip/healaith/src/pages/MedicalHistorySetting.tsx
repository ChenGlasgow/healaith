"use client"

import { Button, Form, Input, Layout } from "antd"
import { useSession } from "next-auth/react"
import Link from "next/link"
import React, { useEffect } from "react"

import SiteHeader from "@/components/SiteHeader"
import { QuestionCircleOutlined } from "@ant-design/icons"

const { Content, Footer } = Layout

const formItemLayout = {
  labelCol: {
    xs: { span: 24 },
    sm: { span: 8 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 16 },
  },
}

const tailFormItemLayout = {
  wrapperCol: {
    xs: {
      span: 24,
      offset: 0,
    },
    sm: {
      span: 16,
      offset: 8,
    },
  },
}

const App: React.FC = () => {
  const [form] = Form.useForm()
  const { data: session, status } = useSession()

  const onFinish = async (values: any) => {
    await fetch("/api/settings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        data: values,
      }),
    })
    alert("Success!") // TODO
  }

  useEffect(() => {
    if (session) {
      fetch("/api/settings")
        .then((res) => res.json())
        .then((data) => {
          form.setFieldsValue(data.data)
        })
    }
  }, [session])

  return (
    <Layout className="layout min-h-screen">
      <SiteHeader />
      <Content style={{ padding: "0 50px" }} className="flex justify-center">
        <div className="site-layout-content flex justify-center">
          <Form
            {...formItemLayout}
            form={form}
            name="register"
            onFinish={onFinish}
            initialValues={{
              residence: ["zhejiang", "hangzhou", "xihu"],
              prefix: "86",
            }}
            style={{ width: 700 }}
            scrollToFirstError
          >
            <Form.Item
              name="Past illnesses"
              label="Past illnesses"
              rules={[
                { required: true, message: "Please input Past illnesses" },
              ]}
            >
              <Input.TextArea
                showCount
                maxLength={100}
                placeholder="Please list the diseases that you have had or are currently suffering from, such as hypertension, diabetes, heart disease, etc."
              />
            </Form.Item>

            <Form.Item
              name="Surgical history"
              label="Surgical history"
              rules={[
                { required: true, message: "Please input Surgical history" },
              ]}
            >
              <Input.TextArea
                showCount
                maxLength={100}
                placeholder="Please record the surgeries that have been performed, including the type of surgery, the date of surgery, and the purpose of the surgery."
              />
            </Form.Item>
            <Form.Item
              name="Allergy history"
              label="Allergy history"
              rules={[
                { required: true, message: "Please input Allergy history" },
              ]}
            >
              <Input.TextArea
                showCount
                maxLength={100}
                placeholder="Please record whether there have been allergic reactions to drugs, food, or environmental factors, including allergens and allergic symptoms."
              />
            </Form.Item>
            <Form.Item
              name="Previous drug treatment"
              label="Previous drug treatment"
              rules={[
                {
                  required: true,
                  message: "Please input Previous drug treatment",
                },
              ]}
            >
              <Input.TextArea
                showCount
                maxLength={100}
                placeholder="Please list the drugs that have been used in the past or are currently being used, including drug names, dosage, and duration of use."
              />
            </Form.Item>
            <Form.Item
              name="Family medical history"
              label="Family medical history"
              rules={[
                {
                  required: true,
                  message: "Please input Family medical history",
                },
              ]}
            >
              <Input.TextArea
                showCount
                maxLength={100}
                placeholder="Please record the situation of whether immediate relatives (parents, siblings, children) have hereditary diseases or suffer from certain specific diseases."
              />
            </Form.Item>
            <Form.Item
              name="Living habits"
              label="Living habits"
              rules={[
                { required: true, message: "Please input Living habits" },
              ]}
            >
              <Input.TextArea
                showCount
                maxLength={100}
                placeholder="Including dietary habits, smoking and drinking status, as well as whether engaged in specific occupations or affected by specific environmental factors."
              />
            </Form.Item>

            <Form.Item {...tailFormItemLayout}>
              <Button type="primary" htmlType="submit">
                Submit
              </Button>
            </Form.Item>
          </Form>
        </div>
      </Content>
      <Link href="/demo">
        <div>
          <Button
            type="primary"
            shape="circle"
            icon={<QuestionCircleOutlined />}
            style={{
              position: "fixed",
              right: 24,
              bottom: 24,
              marginBottom: "24px",
            }}
          />
        </div>
      </Link>
      <Footer style={{ textAlign: "center" }}>©HealAIth</Footer>
    </Layout>
  )
}

export default App
