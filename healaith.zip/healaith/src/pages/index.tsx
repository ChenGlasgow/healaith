import {
  Button,
  Card,
  Col,
  Collapse,
  ConfigProvider,
  Form,
  Popover,
  Rate,
  Row,
  Statistic,
  theme,
} from "antd"
import type { CollapseProps } from "antd"
import { signIn, signOut, useSession } from "next-auth/react"
import Image from "next/image"
import Link from "next/link"
import { useEffect, useState } from "react"

import {
  CaretDownOutlined,
  LikeOutlined,
  QuestionCircleOutlined,
} from "@ant-design/icons"

import LoginButton from "../components/LoginButton"

const collapseItems: CollapseProps["items"] = [
  {
    key: "1",
    label: "Symptom input and automated diagnosis",
    children: (
      <>
        <p>- Users can input symptoms and health issues.</p>
        <p>
          - The system is able to perform automated diagnosis and provide
          recommendations based on the information provided by users.
        </p>
      </>
    ),
  },
  {
    key: "2",
    label: "Disease search and information browsing",
    children: (
      <>
        <p>
          - Users can search for relevant information about specific diseases.
        </p>
        <p>
          - The website provides detailed information on the symptoms, treatment
          methods, preventive measures, and other aspects of diseases.
        </p>
      </>
    ),
  },
  {
    key: "3",
    label: "History search and view",
    children: (
      <p>
        Users can view the historical records of previously entered symptoms and
        health issues.
      </p>
    ),
  },
]

const Home = () => {
  const {
    token: { colorBgContainer },
  } = theme.useToken()

  const [form] = Form.useForm()
  const { data: session, status } = useSession()
  const [rating, setRating] = useState(2.5)

  const onFinish = async (value: number) => {
    try {
      await fetch("/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          rating: value,
        }),
      })
      console.log("Feedback sent successfully!")
    } catch (error) {
      console.error("Error sending feedback:", error)
    }
  }

  useEffect(() => {
    if (session) {
      fetch("/api/feedback")
        .then((res) => res.json())
        .then((data) => {
          const averageRating =
            data.reduce(
              (sum: any, feedback: { rating: any }) => sum + feedback.rating,
              0,
            ) / data.length
          setRating(averageRating)
        })
        .catch((error) => {
          console.error("Error fetching feedback data:", error)
        })
    }
  }, [session])
  return (
    <ConfigProvider
      theme={{
        token: {
          colorTextHeading: "#fff",
          colorBgLayout: "#000",
          colorBgElevated: "#000",
          colorBgContainer: "#000",
          colorText: "#fff",
        },
      }}
    >
      <div className="px-20 bg-black text-cyan-500">
        <div className="h-screen flex items-center justify-center text-center space-y-8 flex-col bg-[url('/1.webp')] bg-no-repeat bg-center mb-10 style={{backgroundImage: `url('/1.webp')`, backgroundSize: 'cover', backgroundRepeat: 'no-repeat'}}">
          <Image
            alt="medical"
            width={50}
            height={50}
            style={{ borderRadius: "50%" }}
            src="/logo.png"
          />
          <div className="text-5xl">Welcome to HealAIth</div>
          <div className="text-xl text-zinc-400">We are here to help you</div>
          <div className="space-x-4">
            <ConfigProvider
              theme={{
                token: {
                  colorBgContainer: "#fff",
                },
              }}
            >
              {session ? (
                <Button type="primary" size="large">
                  <Link href="/chat">Chat with AI</Link>
                </Button>
              ) : (
                <Button type="primary" size="large" onClick={() => signIn()}>
                  Chat with AI
                </Button>
              )}
            </ConfigProvider>
            <Button className=" text-white" type="default" size="large">
              <Link href="/demo" role="demolink">
                Demo
              </Link>
            </Button>
          </div>
        </div>
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 text-center">
          <div className="mb-2">Explore the HealAIth way</div>
          <CaretDownOutlined className="text-2xl" />
        </div>

        <div className="px-20 mb-20">
          <div className="h-2/3 flex items-center justify-center">
            <div className="w-1/2 mr-10 space-y-8">
              <div className="flex justify-center">
                <Image
                  alt="medical"
                  width={400}
                  height={400}
                  src="/2.webp"
                  style={{ borderRadius: "90%" }}
                />
              </div>
            </div>
            <div className="w-1/2 flex items-center flex-col">
              <div className="text-5xl">Why Choose Us</div>
              <div className="flex h-36 mt-8  colorBgElevated=#ffffff">
                <Popover title="Free service" trigger="hover">
                  <Button style={{ color: "white" }}> Low-Cost </Button>
                </Popover>
                <Popover
                  className=" self-end"
                  title="Users can set and manage their own medical history information"
                  trigger="hover"
                >
                  <Button style={{ color: "white" }}>
                    Personalized Service{" "}
                  </Button>
                </Popover>
                <Popover title="Chat anytime" trigger="hover">
                  <Button style={{ color: "white" }}>Convenient</Button>
                </Popover>
              </div>
            </div>
          </div>
        </div>

        <div className="px-20 bg-black text-white">
          <div className="h-2/3 flex items-center justify-center">
            <div className="w-1/2 mr-10 space-y-8 flex items-center flex-col">
              <div className="text-5xl ">What We Offer</div>
              <Collapse accordion items={collapseItems}></Collapse>
            </div>
            <div className="w-1/2">
              <div className="flex justify-center">
                <Image alt="medical" width={400} height={400} src="/4.png" />
              </div>
            </div>
          </div>
        </div>

        {/* Feedback section */}
        <h2
          style={{
            textAlign: "center",
            fontSize: "36px",
            fontWeight: "bold",
            marginBottom: "24px",
          }}
        >
          Feedback
        </h2>

        <Rate
          allowHalf
          value={rating}
          className="m-3"
          onChange={(value) => {
            setRating(value)
            onFinish(value)
          }}
        />
        <ConfigProvider
          theme={{
            token: {
              colorBgContainer: "#fff",
            },
          }}
        >
          <Link href="/demo">
            <div>
              <Button
                type="primary"
                shape="circle"
                icon={<QuestionCircleOutlined />}
                style={{
                  position: "fixed",
                  right: 24,
                  bottom: 24,
                  marginBottom: "24px",
                }}
              />
            </div>
          </Link>
        </ConfigProvider>
        <div className="text-center">©HealAIth</div>
      </div>
    </ConfigProvider>
  )
}

export default Home
