import { NextApiRequest, NextApiResponse } from "next"
import { getServerSession } from "next-auth/next"

import prisma from "@/lib/prisma.server"

import { authOptions } from "./auth/[...nextauth]"

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse,
) {
  if (req.method === "POST") {
    const session = await getServerSession(req, res, authOptions)
    const { data } = req.body
    if (!session?.user?.email) {
      return res.status(401).json({ error: "Unauthorized" })
    }
    await prisma.user.update({
      where: {
        email: session.user.email,
      },
      data: {
        settings: JSON.stringify(data),
      },
    })
    res.status(200).json({ data })
  } else if (req.method === "GET") {
    const session = await getServerSession(req, res, authOptions)
    if (!session?.user?.email) {
      return res.status(401).json({ error: "Unauthorized" })
    }
    const user = await prisma.user.findUnique({
      where: {
        email: session.user.email,
      },
    })
    res
      .status(200)
      .json({ data: user?.settings ? JSON.parse(user?.settings) : null })
  }
}
