import { OpenAIStream, streamToResponse } from "ai"
import { NextApiRequest, NextApiResponse } from "next"
import { getServerSession } from "next-auth"
import { NextRequest } from "next/server"
import { Configuration, OpenAIApi } from "openai-edge"

import prisma from "@/lib/prisma.server"

import { authOptions } from "./auth/[...nextauth]"

const config = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})

const openai = new OpenAIApi(config)

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse,
) {
  const session = await getServerSession(req, res, authOptions)

  if (req.method === "POST") {
    if (!session?.user?.email) {
      return res.status(401).json({ error: "Unauthorized" })
    }

    const { messages } = JSON.parse(req.body)

    try {
      const chatRecord = await prisma.chatRecord.findFirst({
        where: {
          userId: session.user.email!,
        },
      })
      if (chatRecord) {
        await prisma.chatRecord.update({
          where: {
            id: chatRecord.id,
          },
          data: {
            messages: messages,
            timestamp: new Date().toISOString(),
          },
        })
      } else {
        await prisma.chatRecord.create({
          data: {
            userId: session.user.email!,
            messages: messages,
            timestamp: new Date().toISOString(),
          },
        })
      }
    } catch (error) {
      console.error("Error saving chat record:", error)
      res.status(500).json({ error: "Failed to save chat record" })
    }
    if (messages[0].role !== "system") {
      messages.unshift({
        role: "system",
        content: "roleplay like a doctor.",
      })
    }
    const aiResponse = await openai.createChatCompletion({
      model: "gpt-4",

      stream: true,
      messages: messages,
      temperature: 0.3,
    })

    const stream = OpenAIStream(aiResponse)

    /**
     * Converts the stream to a Node.js Response-like object
     */
    return streamToResponse(stream, res)
  } else if (req.method === "GET") {
    try {
      const allChatRecords = await prisma.chatRecord.findMany()
      res.status(200).json(allChatRecords)
    } catch (error) {
      console.error("Error fetching chat records:", error)
      res.status(500).json({ error: "Failed to fetch chat records" })
    }
  } else {
    res.status(405).json({ error: "Method not allowed" })
  }
}
