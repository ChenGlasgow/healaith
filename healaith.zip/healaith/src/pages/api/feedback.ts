import { NextApiRequest, NextApiResponse } from "next"

import prisma from "@/lib/prisma.server"

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse,
) {
  if (req.method === "POST") {
    const { rating } = req.body
    if (!rating || typeof rating !== "number") {
      return res.status(400).json({ error: "Invalid rating format" })
    }

    try {
      await prisma.feedback.create({
        data: {
          message: "",
          rating,
        },
      })
      res.status(200).json({ success: true })
    } catch (error) {
      console.error("Error saving feedback:", error)
      res.status(500).json({ error: "Failed to save feedback" })
    }
  } else if (req.method === "GET") {
    try {
      const allFeedback = await prisma.feedback.findMany()
      res.status(200).json(allFeedback)
    } catch (error) {
      console.error("Error fetching feedback:", error)
      res.status(500).json({ error: "Failed to fetch feedback" })
    }
  } else {
    res.status(405).json({ error: "Method not allowed" })
  }
}
