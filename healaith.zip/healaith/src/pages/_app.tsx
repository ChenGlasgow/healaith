import type { AppProps } from "next/app"

import Providers from "@/components/Providers"

import "../css/globals.css"

export default function MyApp({
  Component,
  pageProps: { session, ...pageProps },
}: AppProps) {
  return (
    <Providers session={session}>
      <Component {...pageProps} />
    </Providers>
  )
}
