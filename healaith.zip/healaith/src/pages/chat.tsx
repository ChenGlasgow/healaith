"use client"

import { useChat } from "ai/react"
import { Button, Form, Input, Layout, Rate, theme } from "antd"
import { useSession } from "next-auth/react"
import Link from "next/link"
import React, { useEffect, useState } from "react"

import SiteHeader from "@/components/SiteHeader"
import { QuestionCircleOutlined } from "@ant-design/icons"

interface Message {
  text: string
  user: boolean
}

const { Content, Footer } = Layout
const { TextArea } = Input

const App: React.FC = () => {
  const [message, setMessage] = useState("")
  const [messagesState, setMessagesState] = useState<Array<Message>>([])
  const {
    messages,
    input,
    handleInputChange: chatHandleInputChange,
    handleSubmit,
  } = useChat()
  const [form] = Form.useForm()
  const { data: session, status } = useSession()

  const [rating, setRating] = useState(2.5)

  const onFinish = async (value: number) => {
    try {
      await fetch("/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          rating: value,
        }),
      })
      console.log("Feedback sent successfully!")
    } catch (error) {
      console.error("Error sending feedback:", error)
    }
  }

  useEffect(() => {
    if (session) {
      fetch("/api/feedback")
        .then((res) => res.json())
        .then((data) => {
          const averageRating =
            data.reduce(
              (sum: any, feedback: { rating: any }) => sum + feedback.rating,
              0,
            ) / data.length
          setRating(averageRating)
        })
        .catch((error) => {
          console.error("Error fetching feedback data:", error)
        })
    }
  }, [session])
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(e.target.value)
  }

  const renderedMessages = messagesState.map(
    (
      messageObj: {
        user: any
        text:
          | string
          | number
          | boolean
          | React.ReactElement<any, string | React.JSXElementConstructor<any>>
          | Iterable<React.ReactNode>
          | React.ReactPortal
          | React.PromiseLikeOfReactNode
          | null
          | undefined
      },
      idx: React.Key | null | undefined,
    ) => {
      return (
        <div
          key={idx}
          style={{
            display: "flex",
            justifyContent: messageObj.user ? "flex-end" : "flex-start",
          }}
        >
          <p>{messageObj.text}</p>
        </div>
      )
    },
  )

  const {
    token: { colorBgContainer },
  } = theme.useToken()

  return (
    <Layout className="layout min-h-screen">
      <SiteHeader />
      <Content style={{ padding: "0 50px" }} className="flex justify-center">
        <div
          className="site-layout-content flex justify-center flex-col items-center text-center w-full"
          style={{ background: colorBgContainer }}
        >
          <div className=" h-96 w-full bg-slate-200">
            <div className="message-list">
              {renderedMessages}
              {messages.map(
                (m: {
                  id: React.Key | null | undefined
                  role: string
                  content:
                    | string
                    | number
                    | boolean
                    | React.ReactElement<
                        any,
                        string | React.JSXElementConstructor<any>
                      >
                    | Iterable<React.ReactNode>
                    | React.ReactPortal
                    | React.PromiseLikeOfReactNode
                    | null
                    | undefined
                }) => (
                  <div key={m.id}>
                    {m.role === "user" ? "User: " : "AI: "}
                    {m.content}
                  </div>
                ),
              )}
            </div>
          </div>
          <div className="flex w-full items-center">
            <form className="flex-1" onSubmit={handleSubmit}>
              <Input
                id="inputBox"
                value={input}
                onChange={chatHandleInputChange}
                placeholder="Enter your symptoms here"
                style={{ marginRight: "8px", flex: 1 }}
              />

              <Button
                className="h-full bg-[#00b96b]"
                type="primary"
                htmlType="submit"
              >
                Submit
              </Button>
            </form>
          </div>
          <Rate
            allowHalf
            value={rating}
            className="m-3"
            onChange={(value) => {
              setRating(value)
              onFinish(value)
            }}
          />{" "}
        </div>
      </Content>
      <Link href="/demo">
        <div>
          <Button
            type="primary"
            shape="circle"
            icon={<QuestionCircleOutlined />}
            style={{
              position: "fixed",
              right: 24,
              bottom: 24,
              marginBottom: "24px",
            }}
          />
        </div>
      </Link>
      <Footer style={{ textAlign: "center" }}>©HealAIth</Footer>
    </Layout>
  )
}

export default App
